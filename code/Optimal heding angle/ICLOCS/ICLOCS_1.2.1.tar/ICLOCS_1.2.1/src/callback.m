function b=callback(t,f,x)

b = true;
